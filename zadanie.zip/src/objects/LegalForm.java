package objects;

public enum LegalForm {
    NATURAL,
    LEGAL
}
